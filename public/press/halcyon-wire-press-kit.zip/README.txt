Halcyon Wire: press kit placeholder

Replace this file with your real press kit: high-resolution photos, logos, cover art and a one-sheet.

Short bio
Halcyon Wire is a four-piece synth-rock band from Lake Arden, Minnesota, known for big-hearted choruses, analog synths and a live show that runs on pure volume.
